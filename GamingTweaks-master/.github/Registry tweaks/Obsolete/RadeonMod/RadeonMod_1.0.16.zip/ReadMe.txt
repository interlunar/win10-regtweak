RadeonMod.

A small application that allows you to edit registry values for Radeon GPU's.
Changes will be active after a system reboot or clicking "Restart Driver".

Be sure to backup your registry first by going to File and then Backup Registry.

Black options exist already and can be edited.
Red options don't exist but will be added when edited.

Please understand that you use at your own risk.

Supported hardware:

Radeon R9 Fury, R9 300, and R7 300 Series
Radeon R9 200, R7 200, HD 7000, HD 6000, and HD 5000 Series
AMD Mobility Radeon� Notebooks
Radeon� HD 4000, HD 3000, and HD 2000 Series
AMD Radeon Dual Graphics�

RadeonMod and it's creator are in no way affiliated with AMD.

Copyright 2010 - 2017 by error-soft.net - All rights reserved