PurgeMemoryCacheService is a tool for purging the overgrown standby list and/or file cache to increase free physical memory.
Tool is written in C# language as a system service (managed by Service Control Manager).

File 'setup.bat' performs following steps:
- builds the binary file 'PurgeMemoryCacheService.exe' from the source file 'PurgeMemoryCacheService.cs';
- creates template ini-file for service if ini-file is absent;
- opens ini-file in notepad.exe for user to customize;
- creates service 'PMCS' in OS (SCM) with auto start;
- starts the service.

File 'cleanup.bat' performs following steps:
- stops the 'PMCS' service;
- deletes the 'PMCS' service;
- deletes the binary file 'PurgeMemoryCacheService.exe'.

All configuration is done in ini-file named 'PurgeMemoryCacheService.exe.ini'. 
ini-file can contain any number of so called purge queries - one query per line.
Empty lines and lines started with '#' are ignored.

Purge query has following syntax:

	purge <targets> on <schedule>(<options>) [with treshold(<XXX>)]

where
<targets> - enumerates what should be purged - 'StandbyList', or 'FileCache', or both ('StandbyList,FileCache');
<schedule> - specifies how the purge should be initiated - by the 'timer', by the 'start' or 'stop' (of listed in <options> processes);
<options> - either the interval of timer in minutes or the list of exe-file names (with '.exe', and separated by ',');
with treshold(<XXX>) - is optional check of the available physical memory against treshold value <XXX> (in megabytes) 
to finish the purging only if available memory is lower.

Patterns of process names in <options> for the 'start' and 'stop' schedules.
Since WMI is used for the monitoring of processes user can use special wildcard symbol '%' to specify not exact names 
of processes but patterns. '%' means any string of zero or more characters. Just like wildcard '*' in file operations in DOS/Windows.
For example, the purge query 
	purge <targets> on start(%editor.exe,%64%.exe)
will monitor the start of all processes with the name ending with 'editor.exe' and all processes having '64' somewhere in the name.

  
Examples of queries: 
- purge standby list and file cache checking every 60 minutes whether available memory is lower then 500MB
	purge StandbyList,FileCache on timer(60) with treshold(500)
	
- purge standby list checking on every start of 'notepad.exe' whether available memory is lower then 500MB
	purge StandbyList on start(notepad.exe) with treshold(500)

- purge standby list and file cache checking on every stop of processes with name pattern '%word.exe' whether available memory is lower then 1000MB
	purge StandbyList,FileCache on stop(%word.exe) with treshold(1000)

- purge file cache every 120 minutes (without the check whether available memory is low)
	purge FileCache on timer(120)

Implementation notes.
Service guarantees that purging is done only for one purge query at a time, eliminating the race condition.
Purging of file cache is done with 'SetSystemFileCacheSize' Win API function.
Purging of standby list is done with 'NtSetSystemInformation' Win API function.
Available memory treshold value is checked against the performance counter "\Memory\Free & Zero Page List Bytes".
Service creates event log with the name 'PurgeMemoryCacheService' under the 'Application and Services Logs' root node (in Event Viewer).
Only warning and error events have IDs greater than 0.
